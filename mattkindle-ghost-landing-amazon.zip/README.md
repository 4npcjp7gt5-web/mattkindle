# Matt Kindle — Ghost landing page

Drop-in Astro page for `https://mattkindle.com/ghost`.

## Files
- `src/pages/ghost.astro`
- `public/ghost-cover.png`

## Install
Copy both into the matching folders in your existing mattkindle.com Astro project, commit, and deploy.

The Spotify, Apple Music, YouTube, and Amazon Music buttons already contain the supplied live links.

The page includes Open Graph / Twitter metadata using:
`https://mattkindle.com/ghost-cover.png`
